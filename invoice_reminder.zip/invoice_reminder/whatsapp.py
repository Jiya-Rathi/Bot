# invoice_reminder/whatsapp.py

def send_whatsapp_prompt(user_id, message):
    print(f"📤 WhatsApp Message → {user_id}: {message}")
